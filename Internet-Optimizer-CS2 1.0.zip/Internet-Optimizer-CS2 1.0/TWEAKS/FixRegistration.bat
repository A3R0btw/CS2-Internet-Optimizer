@echo off & setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1
title CS2 Optimizer — FixRegistration by a3r0btw
color 0A

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] Запрос прав администратора...
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "Start-Process cmd -ArgumentList '/k cd /d ""%~dp0"" ^&^& ""%~f0""' -Verb RunAs"
    pause
    exit /b
)

echo.
echo ===================================================
echo    CS2 INTERNET OPTIMIZER — FixRegistration v1.0
echo ===================================================
echo.

echo [1/7] Поиск сетевых адаптеров...
set "REG_CLASS=HKLM\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}"

for /f "tokens=1,* delims=" %%A in (
  'reg query "%REG_CLASS%" /s /f * /k ^| findstr /ri "\\[0-9][0-9][0-9][0-9]$"'
) do (
  set "P=%%A"
  set "MID="
  set "VEN="
  set "IID="

  for /f "tokens=2,*" %%i in ('reg query "!P!" /v MatchingDeviceId 2^>^&1 ^| findstr /i "REG_"') do set "MID=%%j"
  if defined MID set "MID=!MID:  = !"

  if /i "!MID:~0,4!"=="PCI\" (
    for /f "tokens=1-4 delims=\&" %%p in ("!MID!") do set "VEN=%%q"

    reg delete "!P!" /v "*SpeedDuplex" /f >nul 2>&1
    reg delete "!P!" /v "SpeedDuplex" /f >nul 2>&1
    reg add "!P!" /v "PnPCapabilities" /t REG_DWORD /d 24 /f >nul 2>&1

    call :ApplyProfile_COMMON "!P!"
    if /i "!VEN!"=="VEN_8086" call :ApplyProfile_INTEL "!P!"
    if /i "!VEN!"=="VEN_10EC" call :ApplyProfile_REALTEK "!P!"
    if /i "!VEN!"=="VEN_15B3" call :ApplyProfile_MELLANOX "!P!"
    if /i "!VEN!"=="VEN_11AB" call :ApplyProfile_MARVELL "!P!"

    for /f "tokens=2,*" %%i in ('reg query "!P!" /v NetCfgInstanceId 2^>^&1 ^| findstr /i "REG_"') do set "IID=%%j"

    if defined IID call :RestartAdapter "!IID!"
  )
)

echo [2/7] Очистка NetBT и NetBIOS...
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NetBT" /v "Start" /t REG_DWORD /d 4 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NetBIOS" /v "Start" /t REG_DWORD /d 4 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NetBT\Parameters" /v "EnableLMHOSTS" /t REG_DWORD /d 0 /f >nul 2>&1

echo [3/7] TCP интерфейсы и глобальные параметры...
where powershell >nul 2>&1
if !errorlevel! equ 0 (
  for /f "delims=" %%i in ('powershell -command "Get-NetAdapter | %% { $_.InterfaceGuid }"') do (
    reg add "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\%%i" /v "TcpAckFrequency" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\%%i" /v "TcpDelAckTicks" /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\%%i" /v "TcpNoDelay" /t REG_DWORD /d 1 /f >nul 2>&1
  )
)

reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpNoDelay" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpAckFrequency" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "DefaultTTL" /t REG_DWORD /d 65 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "Tcp1323Opts" /t REG_DWORD /d 0 /f >nul 2>&1

echo [4/7] Отключение троттлинга и мультимедиа...
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /t REG_DWORD /d 4294967295 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NoLazyMode" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "LazyModeTimeout" /t REG_DWORD /d 4294967295 /f >nul 2>&1

echo [5/7] QoS DSCP 46 для CS2...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetQosPolicy -Name 'CS2 Gaming' -ErrorAction SilentlyContinue | Remove-NetQosPolicy -Confirm:$false" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "New-NetQosPolicy -Name 'CS2 Gaming' -AppPathNameMatchCondition 'cs2.exe' -DSCPValue 46 -IPProtocol MatchAll -PriorityValue8021Action 3 -NetworkProfile All -PolicyStore ActiveStore" >nul 2>&1

:: =================================================
:: СЮДА МОЖЕТЕ ВСТАВИТЬ НАСТРОЙКИ QoS ДЛЯ ДРУГИХ ИГР
:: =================================================


echo [6/7] Отключение энергосбережения PCIe...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-WmiObject MSPower_DeviceEnable -Namespace root\wmi | ForEach-Object { $_.enable = $false; $_.psbase.put(); }" >nul 2>&1

echo [7/7] Отключение Memory Integrity...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /t REG_DWORD /d 0 /f >nul 2>&1

echo.
echo =================================================
echo   П Е Р Е З А Г Р У З И Т Е   К О М П Ь Ю Т Е Р
echo =================================================
echo.
echo От a3r0btw
echo.
pause
exit /b


:ApplyProfile_COMMON
set "PK=%~1"
call :ApplyProfileValues "!PK!" LIST_COMMON
goto :eof

:ApplyProfile_INTEL
set "PK=%~1"
call :ApplyProfileValues "!PK!" LIST_INTEL
goto :eof

:ApplyProfile_REALTEK
set "PK=%~1"
call :ApplyProfileValues "!PK!" LIST_REALTEK
goto :eof

:ApplyProfile_MELLANOX
set "PK=%~1"
call :ApplyProfileValues "!PK!" LIST_MELLANOX
goto :eof

:ApplyProfile_MARVELL
set "PK=%~1"
call :ApplyProfileValues "!PK!" LIST_MARVELL
goto :eof

:ApplyProfileValues
set "PK=%~1"
set "LL=%~2"
if not defined PK goto :eof
if not defined LL goto :eof
set "_list_file=%TEMP%\net_profile_%RANDOM%.txt"
call :%LL% > "!_list_file!"
for /f "usebackq tokens=1,2 delims==" %%X in ("!_list_file!") do (
  set "KN=%%~X"
  set "VT=%%~Y"
  for /f "tokens=1,2 delims=:" %%R in ("!VT!") do (
    set "TT=%%~R"
    set "DD=%%~S"
  )
  reg add "!PK!" /v "!KN!" /t !TT! /d "!DD!" /f >nul 2>&1
)
del "!_list_file!" >nul 2>&1
goto :eof

:LIST_COMMON
echo *DeviceSleepOnDisconnect=REG_SZ:0
echo *EncapsulatedPacketTaskOffload=REG_SZ:1
echo *EncapsulatedPacketTaskOffloadNvgre=REG_SZ:1
echo *EncapsulatedPacketTaskOffloadVxlan=REG_SZ:1
echo *FlowControl=REG_SZ:0
echo *IPChecksumOffloadIPv4=REG_SZ:3
echo *IPsecOffloadV1IPv4=REG_SZ:3
echo *IPsecOffloadV2=REG_SZ:3
echo *IPsecOffloadV2IPv4=REG_SZ:3
echo *LsoV1IPv4=REG_SZ:1
echo *LsoV2IPv4=REG_SZ:1
echo *LsoV2IPv6=REG_SZ:1
echo *PMARPOffload=REG_SZ:1
echo *PMNSOffload=REG_SZ:1
echo *PMWiFiRekeyOffload=REG_SZ:1
echo *PacketDirect=REG_SZ:1
echo *RscIPv4=REG_SZ:1
echo *RscIPv6=REG_SZ:1
echo *TCPChecksumOffloadIPv4=REG_SZ:3
echo *TCPChecksumOffloadIPv6=REG_SZ:3
echo *TCPConnectionOffloadIPv4=REG_SZ:3
echo *TCPConnectionOffloadIPv6=REG_SZ:3
echo *TCPUDPChecksumOffloadIPv4=REG_SZ:3
echo *TCPUDPChecksumOffloadIPv6=REG_SZ:3
echo *UDPChecksumOffloadIPv4=REG_SZ:3
echo *UDPChecksumOffloadIPv6=REG_SZ:3
echo *UdpRsc=REG_SZ:1
echo *UsoIPv4=REG_SZ:1
echo *UsoIPv6=REG_SZ:1
echo ForceRscEnabled=REG_SZ:1
echo *RSS=REG_SZ:1
exit /b

:LIST_INTEL
echo *ModernStandbyWoLMagicPacket=REG_SZ:0
echo *SelectiveSuspend=REG_SZ:0
echo *WakeOnMagicPacket=REG_SZ:0
echo *WakeOnPattern=REG_SZ:0
echo EnablePME=REG_SZ:0
echo LogLinkStateEvent=REG_SZ:0
echo WaitAutoNegComplete=REG_SZ:0
echo WakeOnLink=REG_SZ:0
echo DMACoalescing=REG_SZ:0
echo EEELinkAdvertisement=REG_SZ:0
echo *NicAutoPowerSaver=REG_SZ:0
echo EnableModernStandby=REG_SZ:0
echo EnablePowerManagement=REG_SZ:0
echo ForceWakeFromMagicPacketOnModernStandby=REG_SZ:0
echo WakeFromS5=REG_SZ:0
echo WakeOn=REG_SZ:0
echo LinkNegotiationProcess=REG_SZ:0
echo WaitForValidPhyIDRead=REG_SZ:0
echo SleepWhileWaiting=REG_SZ:0
echo EnableETW=REG_SZ:0
echo OBFFEnabled=REG_SZ:0
echo I218DisablePLLShut=REG_SZ:1
echo I218DisablePLLShutGiga=REG_SZ:1
echo I219DisableK1Off=REG_SZ:1
echo DisableIntelRST=REG_SZ:1
echo ForceLtrValue=REG_SZ:0
echo EnableDisconnectedStandby=REG_SZ:0
echo EnableWakeOnManagmentOnTCO=REG_SZ:0
echo EnablePHYFlexibleSpeed=REG_SZ:0
echo EnablePHYWakeUp=REG_SZ:0
echo EnableD0PHYFlexibleSpeed=REG_SZ:0
echo EnableSavePowerNow=REG_SZ:0
echo AutoPowerSaveModeEnabled=REG_SZ:0
echo SipsEnabled=REG_SZ:0
echo WakeOnFastStartup=REG_SZ:0
echo *EnableDynamicPowerGating=REG_SZ:0
echo *EEE=REG_SZ:0
echo EnableD3ColdInS0=REG_SZ:0
echo *SSIdleTimeout=REG_SZ:0
echo SSIdleTimeoutMS=REG_SZ:0
echo LatencyToleranceReporting=REG_SZ:0
echo *VMQ=REG_SZ:0
echo VMQSupported=REG_SZ:0
echo *InterruptModeration=REG_SZ:0
echo EnableAdaptiveQueuing=REG_SZ:0
echo StoreBadPackets=REG_SZ:0
echo DynamicLTR=REG_SZ:0
echo DropHighlyFragmentedPacket=REG_SZ:1
echo EnableCoalesce=REG_SZ:0
echo AllowFlowControlFrames=REG_SZ:0
echo *StoreBadPackets=REG_SZ:0
echo EnableTss=REG_SZ:1
echo *PriorityVLANTag=REG_SZ:0
echo *ReceiveBuffers=REG_SZ:1024
echo *TransmitBuffers=REG_SZ:1024
echo *JumboPacket=REG_SZ:1514
echo *NumRssQueues=REG_SZ:2
exit /b

:LIST_REALTEK
echo *IdleRestriction=REG_SZ:0
echo *VMQ=REG_SZ:0
echo VMQSupported=REG_SZ:0
echo *InterruptModeration=REG_SZ:0
echo EnableAdaptiveQueuing=REG_SZ:0
echo StoreBadPackets=REG_SZ:0
echo DynamicLTR=REG_SZ:0
echo DropHighlyFragmentedPacket=REG_SZ:1
echo EnableCoalesce=REG_SZ:0
echo AllowFlowControlFrames=REG_SZ:0
echo *StoreBadPackets=REG_SZ:0
echo EnableTss=REG_SZ:1
echo *PriorityVLANTag=REG_SZ:0
echo *EEE=REG_SZ:0
echo *SelectiveSuspend=REG_SZ:0
echo *ModernStandbyWoLMagicPacket=REG_SZ:0
echo *WakeOnMagicPacket=REG_SZ:0
echo *WakeOnPattern=REG_SZ:0
echo *JumboPacket=REG_SZ:1514
echo *NumRssQueues=REG_SZ:1
echo S5WakeOnLan=REG_SZ:0
echo WolShutdownLinkSpeed=REG_SZ:2
echo *SSIdleTimeout=REG_SZ:0
echo *SSIdleTimeoutScreenOff=REG_SZ:0
echo AdvancedEEE=REG_SZ:0
echo ASPM=REG_SZ:0
echo CLKREQ=REG_SZ:0
echo EEEPlus=REG_SZ:0
echo EnableAspm=REG_SZ:0
echo EnableGreenEthernet=REG_SZ:0
echo GPPSW=REG_SZ:0
echo EPSDRT=REG_SZ:0
echo GigaLite=REG_SZ:0
echo LTROBF=REG_SZ:0
echo PowerDownPll=REG_SZ:0
echo PowerSavingMode=REG_SZ:0
echo *ReceiveBuffers=REG_SZ:1024
echo *TransmitBuffers=REG_SZ:1024
exit /b

:LIST_MELLANOX
echo *InterruptModeration=REG_SZ:0
echo *NicAutoPowerSaver=REG_SZ:0
echo *JumboPacket=REG_SZ:1514
echo WakeOnPattern=REG_SZ:0
echo WakeOnMagicPacket=REG_SZ:0
echo FwTracerEnabled=REG_SZ:0
echo VfCpuMonEnable=REG_SZ:0
echo VFAllowedRelaxedOrdering=REG_SZ:0
echo *QOS=REG_SZ:0
echo AllowPacketDirect=REG_SZ:1
echo EnableGpuDirect=REG_SZ:1
echo RxIntModeration=REG_SZ:0
echo ThreadedDpcEnable=REG_SZ:0
echo TxIntModeration=REG_SZ:0
echo TxThreadedDpcEnable=REG_SZ:0
echo EnableCmAntiSpoofing=REG_SZ:0
echo *SelectiveSuspend=REG_SZ:0
echo *ReceiveBuffers=REG_SZ:1024
echo *TransmitBuffers=REG_SZ:1024
exit /b

:LIST_MARVELL
echo *InterruptModeration=REG_SZ:0
echo ThermalMonitoring=REG_SZ:0
echo *NicAutoPowerSaver=REG_SZ:0
echo *EEE=REG_SZ:0
echo *JumboPacket=REG_SZ:1514
echo WakeFromPowerOff=REG_SZ:0
echo WakeOnLink=REG_SZ:0
echo WakeOnPing=REG_SZ:0
echo WakeOnPattern=REG_SZ:0
echo WakeOnMagicPacket=REG_SZ:0
echo *ReceiveBuffers=REG_SZ:1024
echo *TransmitBuffers=REG_SZ:1024
exit /b

:RestartAdapter
set "RG=%~1"
if not defined RG goto :eof
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $g = '!RG!'; $filter = 'GUID=''' + $g + ''''; $na = Get-WmiObject Win32_NetworkAdapter -Filter $filter -ErrorAction Stop; $name = $na.NetConnectionId; if (-not $name) { $name = $na.Name }; Disable-NetAdapter -Name $name -Confirm:$false -PassThru -ErrorAction Stop | Out-Null; Start-Sleep -Seconds 2; Enable-NetAdapter -Name $name -Confirm:$false -ErrorAction Stop | Out-Null } catch { }" >nul 2>&1
goto :eof