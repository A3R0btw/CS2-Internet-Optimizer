@echo off
chcp 65001 >nul
title SMART RSS -> LAST 2 CORES
color 0A

:: Admin check
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~f0\"' -Verb RunAs"
    exit /b
)

echo.
echo ==========================================
echo   BINDING RSS - BIND TO LAST CORE
echo ==========================================
echo.

set "PS1=%temp%\rss_last2.ps1"

(
echo $ErrorActionPreference = "Stop"
echo.
echo Write-Host "Detecting CPU threads..." -ForegroundColor Cyan
echo $threads = [Environment]::ProcessorCount
echo Write-Host "Logical threads: $threads" -ForegroundColor Green
echo.
echo if ($threads -lt 4^) {
echo     Write-Host "Too few threads for RSS tuning" -ForegroundColor Red
echo     exit
echo }
echo.
echo # ALWAYS last 2 threads
echo $core1 = $threads - 2
echo $core2 = $threads - 1
echo.
echo Write-Host "Target RSS cores: $core1 and $core2" -ForegroundColor Yellow
echo.
echo $adapters = Get-NetAdapter -Physical ^| Where-Object {
echo     $_.Status -eq "Up" -and $_.InterfaceDescription -notmatch "WiFi|Wireless|Bluetooth|Virtual|VPN"
echo }
echo.
echo foreach ($a in $adapters^) {
echo     Write-Host ""
echo     Write-Host "Adapter: $($a.Name)" -ForegroundColor Yellow
echo.
echo     try {
echo         Set-NetAdapterRss -Name $a.Name `
echo             -BaseProcessorNumber $core1 `
echo             -MaxProcessorNumber $core2 `
echo             -MaxProcessors 2 `
echo             -NumberOfReceiveQueues 2 `
echo             -ErrorAction Stop
echo.
echo         Write-Host "OK -> bound to LAST 2 cores ($core1-$core2)" -ForegroundColor Green
echo     }
echo     catch {
echo         Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
echo     }
echo }
echo.
echo Write-Host ""
echo Write-Host "DONE. REBOOT recommended." -ForegroundColor Cyan
echo Read-Host "Press Enter"
) > "%PS1%"

powershell -ExecutionPolicy Bypass -File "%PS1%"

del "%PS1%"

echo.
echo Finished.
pause