@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title CS2 Optimizer — ПОЛНЫЙ СБРОС НАСТРОЕК
color 0C

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] Запрос прав администратора...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~f0\"' -Verb RunAs"
    exit /b
)

echo.
echo ============================================================
echo         ПОЛНЫЙ СБРОС ВСЕХ НАСТРОЕК (CS2 NETWORK TWEAKS)
echo ============================================================
echo.
echo ВНИМАНИЕ! Будут удалены ВСЕ сетевые твики:
echo   - Параметры драйверов (InterruptModeration, буферы, EEE и др.)
echo   - TCP настройки (TcpNoDelay, TcpAckFrequency, DefaultTTL)
echo   - NetworkThrottlingIndex, NoLazyMode
echo   - QoS политики (CS2, Deadlock)
echo   - Winsock и TCP/IP стек
echo.
set /p "confirm=Вы уверены? (Y/N): "
if /i not "!confirm!"=="Y" (
    echo Отменено.
    pause
    exit /b
)

echo.
echo Сброс настроек...

:: ============================================
:: 1. Полное удаление всех параметров из профилей
:: ============================================
set "REG_CLASS=HKLM\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}"

for /f "tokens=1,* delims=" %%A in (
  'reg query "%REG_CLASS%" /s /f * /k ^| findstr /ri "\\[0-9][0-9][0-9][0-9]$"'
) do (
  set "P=%%A"
  
  :: Стандартные параметры
  reg delete "!P!" /v "*SpeedDuplex" /f >nul 2>&1
  reg delete "!P!" /v "SpeedDuplex" /f >nul 2>&1
  reg delete "!P!" /v "PnPCapabilities" /f >nul 2>&1
  reg delete "!P!" /v "*RssBaseProcNumber" /f >nul 2>&1
  reg delete "!P!" /v "*RssMaxProcNumber" /f >nul 2>&1
  reg delete "!P!" /v "*NumRssQueues" /f >nul 2>&1
  reg delete "!P!" /v "*ReceiveBuffers" /f >nul 2>&1
  reg delete "!P!" /v "*TransmitBuffers" /f >nul 2>&1
  reg delete "!P!" /v "*JumboPacket" /f >nul 2>&1
  reg delete "!P!" /v "*RSS" /f >nul 2>&1

  :: COMMON профиль
  reg delete "!P!" /v "*DeviceSleepOnDisconnect" /f >nul 2>&1
  reg delete "!P!" /v "*EncapsulatedPacketTaskOffload" /f >nul 2>&1
  reg delete "!P!" /v "*EncapsulatedPacketTaskOffloadNvgre" /f >nul 2>&1
  reg delete "!P!" /v "*EncapsulatedPacketTaskOffloadVxlan" /f >nul 2>&1
  reg delete "!P!" /v "*FlowControl" /f >nul 2>&1
  reg delete "!P!" /v "*IPChecksumOffloadIPv4" /f >nul 2>&1
  reg delete "!P!" /v "*IPsecOffloadV1IPv4" /f >nul 2>&1
  reg delete "!P!" /v "*IPsecOffloadV2" /f >nul 2>&1
  reg delete "!P!" /v "*IPsecOffloadV2IPv4" /f >nul 2>&1
  reg delete "!P!" /v "*LsoV1IPv4" /f >nul 2>&1
  reg delete "!P!" /v "*LsoV2IPv4" /f >nul 2>&1
  reg delete "!P!" /v "*LsoV2IPv6" /f >nul 2>&1
  reg delete "!P!" /v "*PMARPOffload" /f >nul 2>&1
  reg delete "!P!" /v "*PMNSOffload" /f >nul 2>&1
  reg delete "!P!" /v "*PMWiFiRekeyOffload" /f >nul 2>&1
  reg delete "!P!" /v "*PacketDirect" /f >nul 2>&1
  reg delete "!P!" /v "*RscIPv4" /f >nul 2>&1
  reg delete "!P!" /v "*RscIPv6" /f >nul 2>&1
  reg delete "!P!" /v "*TCPChecksumOffloadIPv4" /f >nul 2>&1
  reg delete "!P!" /v "*TCPChecksumOffloadIPv6" /f >nul 2>&1
  reg delete "!P!" /v "*TCPConnectionOffloadIPv4" /f >nul 2>&1
  reg delete "!P!" /v "*TCPConnectionOffloadIPv6" /f >nul 2>&1
  reg delete "!P!" /v "*TCPUDPChecksumOffloadIPv4" /f >nul 2>&1
  reg delete "!P!" /v "*TCPUDPChecksumOffloadIPv6" /f >nul 2>&1
  reg delete "!P!" /v "*UDPChecksumOffloadIPv4" /f >nul 2>&1
  reg delete "!P!" /v "*UDPChecksumOffloadIPv6" /f >nul 2>&1
  reg delete "!P!" /v "*UdpRsc" /f >nul 2>&1
  reg delete "!P!" /v "*UsoIPv4" /f >nul 2>&1
  reg delete "!P!" /v "*UsoIPv6" /f >nul 2>&1
  reg delete "!P!" /v "ForceRscEnabled" /f >nul 2>&1

  :: REALTEK профиль (дополнительно)
  reg delete "!P!" /v "*IdleRestriction" /f >nul 2>&1
  reg delete "!P!" /v "*VMQ" /f >nul 2>&1
  reg delete "!P!" /v "VMQSupported" /f >nul 2>&1
  reg delete "!P!" /v "*EEE" /f >nul 2>&1
  reg delete "!P!" /v "*SelectiveSuspend" /f >nul 2>&1
  reg delete "!P!" /v "*WakeOnMagicPacket" /f >nul 2>&1
  reg delete "!P!" /v "*WakeOnPattern" /f >nul 2>&1
  reg delete "!P!" /v "S5WakeOnLan" /f >nul 2>&1
  reg delete "!P!" /v "WolShutdownLinkSpeed" /f >nul 2>&1
  reg delete "!P!" /v "AdvancedEEE" /f >nul 2>&1
  reg delete "!P!" /v "ASPM" /f >nul 2>&1
  reg delete "!P!" /v "CLKREQ" /f >nul 2>&1
  reg delete "!P!" /v "EEEPlus" /f >nul 2>&1
  reg delete "!P!" /v "EnableAspm" /f >nul 2>&1
  reg delete "!P!" /v "EnableGreenEthernet" /f >nul 2>&1
  reg delete "!P!" /v "GPPSW" /f >nul 2>&1
  reg delete "!P!" /v "EPSDRT" /f >nul 2>&1
  reg delete "!P!" /v "GigaLite" /f >nul 2>&1
  reg delete "!P!" /v "LTROBF" /f >nul 2>&1
  reg delete "!P!" /v "PowerDownPll" /f >nul 2>&1
  reg delete "!P!" /v "PowerSavingMode" /f >nul 2>&1

  :: INTEL профиль (дополнительно)
  reg delete "!P!" /v "*ModernStandbyWoLMagicPacket" /f >nul 2>&1
  reg delete "!P!" /v "EnablePME" /f >nul 2>&1
  reg delete "!P!" /v "LogLinkStateEvent" /f >nul 2>&1
  reg delete "!P!" /v "WaitAutoNegComplete" /f >nul 2>&1
  reg delete "!P!" /v "WakeOnLink" /f >nul 2>&1
  reg delete "!P!" /v "DMACoalescing" /f >nul 2>&1
  reg delete "!P!" /v "EEELinkAdvertisement" /f >nul 2>&1
  reg delete "!P!" /v "*NicAutoPowerSaver" /f >nul 2>&1
  reg delete "!P!" /v "EnableModernStandby" /f >nul 2>&1
  reg delete "!P!" /v "EnablePowerManagement" /f >nul 2>&1
  reg delete "!P!" /v "ForceWakeFromMagicPacketOnModernStandby" /f >nul 2>&1
  reg delete "!P!" /v "WakeFromS5" /f >nul 2>&1
  reg delete "!P!" /v "WakeOn" /f >nul 2>&1
  reg delete "!P!" /v "LinkNegotiationProcess" /f >nul 2>&1
  reg delete "!P!" /v "WaitForValidPhyIDRead" /f >nul 2>&1
  reg delete "!P!" /v "SleepWhileWaiting" /f >nul 2>&1
  reg delete "!P!" /v "EnableETW" /f >nul 2>&1
  reg delete "!P!" /v "OBFFEnabled" /f >nul 2>&1
  reg delete "!P!" /v "I218DisablePLLShut" /f >nul 2>&1
  reg delete "!P!" /v "I218DisablePLLShutGiga" /f >nul 2>&1
  reg delete "!P!" /v "I219DisableK1Off" /f >nul 2>&1
  reg delete "!P!" /v "DisableIntelRST" /f >nul 2>&1
  reg delete "!P!" /v "ForceLtrValue" /f >nul 2>&1
  reg delete "!P!" /v "EnableDisconnectedStandby" /f >nul 2>&1
  reg delete "!P!" /v "EnableWakeOnManagmentOnTCO" /f >nul 2>&1
  reg delete "!P!" /v "EnablePHYFlexibleSpeed" /f >nul 2>&1
  reg delete "!P!" /v "EnablePHYWakeUp" /f >nul 2>&1
  reg delete "!P!" /v "EnableD0PHYFlexibleSpeed" /f >nul 2>&1
  reg delete "!P!" /v "EnableSavePowerNow" /f >nul 2>&1
  reg delete "!P!" /v "AutoPowerSaveModeEnabled" /f >nul 2>&1
  reg delete "!P!" /v "SipsEnabled" /f >nul 2>&1
  reg delete "!P!" /v "WakeOnFastStartup" /f >nul 2>&1
  reg delete "!P!" /v "*EnableDynamicPowerGating" /f >nul 2>&1
  reg delete "!P!" /v "EnableD3ColdInS0" /f >nul 2>&1
  reg delete "!P!" /v "*SSIdleTimeout" /f >nul 2>&1
  reg delete "!P!" /v "SSIdleTimeoutMS" /f >nul 2>&1
  reg delete "!P!" /v "LatencyToleranceReporting" /f >nul 2>&1
)

:: ============================================
:: 2. Сброс NetBT и NetBIOS
:: ============================================
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NetBT" /v "Start" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NetBIOS" /v "Start" /t REG_DWORD /d 1 /f >nul 2>&1

:: ============================================
:: 3. Удаление TCP настроек из интерфейсов
:: ============================================
for /f "tokens=1,* delims=\" %%A in ('reg query "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"') do (
  set "guid=%%B"
  if defined guid (
    reg delete "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\!guid!" /v "TcpAckFrequency" /f >nul 2>&1
    reg delete "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\!guid!" /v "TcpDelAckTicks" /f >nul 2>&1
    reg delete "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\!guid!" /v "TcpNoDelay" /f >nul 2>&1
  )
)

:: ============================================
:: 4. Удаление глобальных TCP параметров
:: ============================================
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpNoDelay" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpAckFrequency" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "DefaultTTL" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "Tcp1323Opts" /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "EnableWsd" /t REG_DWORD /d 1 /f >nul 2>&1

:: ============================================
:: 5. Удаление мультимедиа параметров
:: ============================================
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NetworkThrottlingIndex" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "NoLazyMode" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "LazyModeTimeout" /f >nul 2>&1

:: ============================================
:: 6. Сброс RSS через PowerShell
:: ============================================
powershell -NoProfile -ExecutionPolicy Bypass -Command "
    $adapters = Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' -and $_.InterfaceDescription -notmatch 'WiFi|Wireless|Bluetooth|Virtual|VPN' }
    foreach ($a in $adapters) {
        try {
            Set-NetAdapterRss -Name $a.Name -BaseProcessorNumber 0 -MaxProcessorNumber ([Environment]::ProcessorCount - 1) -MaxProcessors ([Environment]::ProcessorCount) -NumberOfReceiveQueues ([Environment]::ProcessorCount / 2) -ErrorAction Stop
        } catch {}
    }
" >nul 2>&1

:: ============================================
:: 7. Включение энергосбережения PCIe обратно
:: ============================================
powershell -Command "Get-WmiObject MSPower_DeviceEnable -Namespace root\wmi | ForEach-Object { $_.enable = $true; $_.psbase.put(); }" >nul 2>&1

:: ============================================
:: 8. Сброс offload настроек
:: ============================================
powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-NetOffloadGlobalSetting -ReceiveSegmentCoalescing Disabled; Set-NetOffloadGlobalSetting -PacketCoalescingFilter Enable" >nul 2>&1

:: ============================================
:: 9. Сброс Winsock и TCP/IP (самое важное)
:: ============================================
netsh winsock reset >nul 2>&1
netsh int ip reset >nul 2>&1

:: ============================================
:: 10. Удаление QoS политик (CS2, Deadlock и др.)
:: ============================================
powershell -Command "Get-NetQosPolicy | Where-Object { $_.Name -like '*Gaming*' -or $_.Name -like '*CS2*' -or $_.Name -like '*Deadlock*' } | Remove-NetQosPolicy -Confirm:$false" >nul 2>&1

:: ============================================
:: 11. Включение Memory Integrity обратно
:: ============================================
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /f >nul 2>&1

echo.
echo =============================================
echo         СБРОС УСПЕШНО ЗАВЕРШЁН
echo =============================================
echo.
echo Что было сброшено:
echo   - Все параметры сетевых адаптеров (InterruptModeration, буферы, EEE и др.)
echo   - TCP настройки (TcpNoDelay, TcpAckFrequency, DefaultTTL)
echo   - NetworkThrottlingIndex, NoLazyMode
echo   - QoS политики (CS2, Deadlock и другие)
echo   - Включено энергосбережение PCIe
echo   - Сброшены Winsock и TCP/IP стек
echo.
echo Для полного применения сброса необходимо
echo перезагрузить компьютер.
echo.
set /p "reboot=Перезагрузить сейчас? (Y/N): "
if /i "!reboot!"=="Y" (
    shutdown /r /t 5 /c "Перезагрузка для применения сброса сетевых настроек"
    echo Перезагрузка через 5 секунд...
) else (
    echo Не забудьте перезагрузить компьютер позже!
    pause
)

exit /b