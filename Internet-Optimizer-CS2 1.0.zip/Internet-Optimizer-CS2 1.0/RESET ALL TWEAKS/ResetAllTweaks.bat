@echo off
chcp 65001 >nul
title CS2 Optimizer — СБРОС ВСЕХ НАСТРОЕК
color 0C

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] Запрос прав администратора...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~f0\"' -Verb RunAs"
    exit /b
)

echo.
echo ============================================================
echo         СБРОС ВСЕХ НАСТРОЕК (CS2 NETWORK TWEAKS)
echo ============================================================
echo.
echo ВНИМАНИЕ! Все сетевые твики будут удалены.
echo Будет выполнен сброс Winsock и TCP/IP стека.
echo.
set /p "confirm=Вы уверены? (Y/N): "
if /i not "!confirm!"=="Y" (
    echo Отменено.
    pause
    exit /b
)

echo.
echo Сброс настроек...

set "REG_CLASS=HKLM\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002BE10318}"
for /f "tokens=1,* delims=" %%A in (
  'reg query "%REG_CLASS%" /s /f * /k ^| findstr /ri "\\[0-9][0-9][0-9][0-9]$"'
) do (
  set "P=%%A"
  reg delete "!P!" /v "*SpeedDuplex" /f >nul 2>&1
  reg delete "!P!" /v "SpeedDuplex" /f >nul 2>&1
  reg delete "!P!" /v "PnPCapabilities" /f >nul 2>&1
  reg delete "!P!" /v "*RssBaseProcNumber" /f >nul 2>&1
  reg delete "!P!" /v "*RssMaxProcNumber" /f >nul 2>&1
  reg delete "!P!" /v "*NumRssQueues" /f >nul 2>&1
  reg delete "!P!" /v "*ReceiveBuffers" /f >nul 2>&1
  reg delete "!P!" /v "*TransmitBuffers" /f >nul 2>&1
  reg delete "!P!" /v "*JumboPacket" /f >nul 2>&1
  reg delete "!P!" /v "*RSS" /f >nul 2>&1
)

reg add "HKLM\SYSTEM\CurrentControlSet\Services\NetBT" /v "Start" /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\NetBIOS" /v "Start" /t REG_DWORD /d 1 /f >nul 2>&1

for /f "tokens=1,* delims=\" %%A in ('reg query "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"') do (
  set "guid=%%B"
  if defined guid (
    reg delete "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\!guid!" /v "TcpAckFrequency" /f >nul 2>&1
    reg delete "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\!guid!" /v "TcpDelAckTicks" /f >nul 2>&1
    reg delete "HKLM\System\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\!guid!" /v "TcpNoDelay" /f >nul 2>&1
  )
)

reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpNoDelay" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "TcpAckFrequency" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "DefaultTTL" /f >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "Tcp1323Opts" /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v "EnableWsd" /t REG_DWORD /d 1 /f >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command "
    $adapters = Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' -and $_.InterfaceDescription -notmatch 'WiFi|Wireless|Bluetooth|Virtual|VPN' }
    foreach ($a in $adapters) {
        try {
            Set-NetAdapterRss -Name $a.Name -BaseProcessorNumber 0 -MaxProcessorNumber ([Environment]::ProcessorCount - 1) -MaxProcessors ([Environment]::ProcessorCount) -NumberOfReceiveQueues ([Environment]::ProcessorCount / 2) -ErrorAction Stop
        } catch {}
    }
" >nul 2>&1

powershell -Command "Get-WmiObject MSPower_DeviceEnable -Namespace root\wmi | ForEach-Object { $_.enable = $true; $_.psbase.put(); }" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-NetOffloadGlobalSetting -ReceiveSegmentCoalescing Disabled; Set-NetOffloadGlobalSetting -PacketCoalescingFilter Enable" >nul 2>&1

netsh winsock reset >nul 2>&1
netsh int ip reset >nul 2>&1

powershell -Command "Get-NetQosPolicy -Name 'CS2 Gaming' -ErrorAction SilentlyContinue | Remove-NetQosPolicy -Confirm:$false" >nul 2>&1
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /f >nul 2>&1

echo.
echo =============================================
echo         СБРОС УСПЕШНО ЗАВЕРШЁН
echo =============================================
echo.
echo Для полного применения сброса необходимо
echo перезагрузить компьютер.
echo.
set /p "reboot=Перезагрузить сейчас? (Y/N): "
if /i "!reboot!"=="Y" (
    shutdown /r /t 5 /c "Перезагрузка для применения сброса сетевых настроек"
    echo Перезагрузка через 5 секунд...
) else (
    echo Не забудьте перезагрузить компьютер позже!
    pause
)

exit /b